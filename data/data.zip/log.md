```python
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [DEBUG]: Запуск parserCompany
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Последняя страница с номером: <17>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Ситидрайв> с ID<1/1>...
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/citydrive/profile/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/citydrive/articles/page1/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <1/1>: LTV и каршеринг — как мы в Ситидрайве считаем приб...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: У компании Ситидрайв: 1 статей
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Школа Le Sallay Диалог> с ID<2/2>...
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/lesallay_dialog/profile/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/lesallay_dialog/articles/page1/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <1/1>: Как обстоят дела со школой в Азии и Европе, на при...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <2/2>: Как распознать хорошее образование...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <3/3>: Есть ли альтернативное образование на Кипре и в Ду...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <4/4>: Об особенностях обучения в школах Сербии и Черного...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <5/5>: Некоторые правила эффективного дистанционного обуч...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <6/6>: Футбол + английский, или что нужно учить сейчас, ч...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <7/7>: Как учат детей в средней школе...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <8/8>: Как устроена система школьного образования в Амери...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <9/9>: Легко ли учить ребенка в Прибалтике в местных школ...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <10/10>: Как выбрать школу для ребенка в Грузии и Армении...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: У компании Школа Le Sallay Диалог: 10 статей
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <EDM Project> с ID<3/3>...
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/edm/profile/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/edm/articles/page1/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: У компании EDM Project: 0 статей
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Сообщество Fitil> с ID<4/4>...
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/fitil/profile/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/fitil/articles/page1/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <1/1>: Принцип мягкой силы в руководстве стартапом...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <2/2>: Fitil о психологии: как чувствовать себя уверенно ...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <3/3>: Любовь и наука: это match...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <4/4>: Как бренду построить своё комьюнити? Рассказываем ...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <5/5>: Знакомьтесь с Fitil. История проекта для поиска др...
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: У компании Сообщество Fitil: 5 статей
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:31] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Quillis> с ID<5/5>...
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/quillis/profile/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:31] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/quillis/articles/page1/>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:31] -> parsers/parserArticles.py -> [INFO]: Статья <1/1>: Мягкость – сестра таланта: soft skills как важнейш...
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Quillis: 1 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Smotion> с ID<6/6>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/smotion/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/smotion/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Smotion: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Всемирный фонд природы> с ID<7/7>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/wwf-russia/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/wwf-russia/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Всемирный фонд природы: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <AlliesVerse> с ID<8/8>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/av/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/av/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании AlliesVerse: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <MoscowCSS митап> с ID<9/9>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/moscowcss/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/moscowcss/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании MoscowCSS митап: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <TEAMLY> с ID<10/10>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/teamly/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/teamly/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Статья <1/1>: Просто о сложном: систематизация знаний с помощью ...
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Статья <2/2>: Как мы внедрили свою же базу знаний в команду разр...
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Статья <3/3>: Будущее управления знаниями: что можно внедрить се...
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании TEAMLY: 3 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Отдел контент-продуктов IT-бренда> с ID<11/11>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/habrabrand/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/habrabrand/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Отдел контент-продуктов IT-бренда: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Кооператив «Рад Коп»> с ID<12/12>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/radcop/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/radcop/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Кооператив «Рад Коп»: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Окама> с ID<13/13>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/okama/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/okama/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Окама: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Получение сведений о компании <Creative Commons> с ID<14/14>...
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/creativecommons/profile/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Запуск ArticleParser
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/creativecommons/articles/page1/>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: Последняя страница с номером: <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [ERROR]: Не удалось получить статьи на странице <1>
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [INFO]: У компании Creative Commons: 0 статей
[23-Jul-23 03:32] -> parsers/parserArticles.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Переход на страницу <https://habr.com/ru/companies/page17/>
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [INFO]: Всего компаний проанализировано: 14
[23-Jul-23 03:32] -> parsers/parserCompany.py -> [DEBUG]: Парсер завершил работу успешно!
[23-Jul-23 03:32] -> parsers/parser.py -> [DEBUG]: Данные успешно записаны
[23-Jul-23 03:32] -> __main__ -> [DEBUG]: Затраченное время: <0.59 минут>
